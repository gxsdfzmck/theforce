# -*- coding: utf-8 -*-
mongo = {'host': 'localhost', 'port': 27017}
mysql = {
    'host': 'mysql.tobeornot.cn',
    'user': 'wutdev',
    'passwd': 'o4mo7XGgweycVe9WTVxg',
    'db': 'raw_data'
}
