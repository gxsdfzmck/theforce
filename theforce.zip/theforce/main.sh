#!/bin/bash
function help(){
    cat << EOF

##################### 帮助 #####################

    格式:
        ./main.sh check|stash|save directory...

    - check: 验证excel中的数据是否可用
    - stash: 验证数据并把它持久化到mongo数据库中
    - save: 从mongo中持久化到mysql中 

EOF
    exit 0
}

if [[ $# -ge 2 ]]; then
    case $1 in
        check|stash|save) python ./src/entry.py $@;;
        *) help;;
    esac
else
    help
fi
